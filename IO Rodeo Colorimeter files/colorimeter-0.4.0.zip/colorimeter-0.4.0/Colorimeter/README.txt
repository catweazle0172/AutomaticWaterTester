colorimeter: Serial library and GUI's for IO Rodeo's OSHW Colorimeter.

Installations instructions can be found in the INSTALL file.

Author: Will Dickson IO Rodeo Inc.

colorimeter may be freely distributed and modified in accordance with the Apache
2.0  License.
